package com.ratrodstudio.androidplugin;

import com.unity3d.player.UnityPlayer;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;

public class InAppBillingManager {

	private static final String TAG = "InAppBillingManager";
	
	private BillingService billingService;
	private Handler handler;
	private InAppPurchaseObserver inAppBillingPurchaseObserver;
	private SharedPreferences prefs;
	
	public static InAppBillingManager sInstance;
	
	private static Context 	context;
	private static Activity activity;
	
	private static boolean hasBillingSupport = false;
	
	public InAppBillingManager(Activity activity){
	    Log.d( TAG, "Starting billing service");
	
	    InAppBillingManager.activity = activity;
	    context = activity.getApplicationContext();
	
	    this.billingService = new BillingService();
	    this.billingService.setContext(context);
	    this.prefs = PreferenceManager.getDefaultSharedPreferences( activity );
	
        handler = new Handler();
        inAppBillingPurchaseObserver = new InAppPurchaseObserver(handler);
        ResponseHandler.register( inAppBillingPurchaseObserver );

	    Log.d( TAG, "Billing service started");
	}
	
	  public static void Init(Activity activity)
	  {
	    if (sInstance == null)
	    {
	    	sInstance = new InAppBillingManager( activity );
	    }
	  }

	  public static void Stop()
	  {
	    Log.d( TAG, "Stopping billing service");

	    if (sInstance != null)
	    {
	      sInstance.billingService.unbind();
	      sInstance.handler.getLooper().quit();
	      sInstance = null;
	    }
	    else
	    {
	      Log.d( TAG, "Stopping failed, never initialized");
	    }
	  }

	  public static boolean IsBillingSupported()
	  {
		  return sInstance.billingService.checkBillingSupported();
	  }
	
	  public static boolean BuyItem ( String productId ){
		  if ( hasBillingSupport == false ){
			  Log.d ( TAG, "No Billing Support Yet!" );
			  return false;
		  }else{
	        	try {
	        		return sInstance.billingService.requestPurchase( productId , null);			  	        		
	        	}catch (Exception ex) {
	        		ex.printStackTrace();
	        	}
		  }
		  return false;
	  }
	
	private class InAppPurchaseObserver extends PurchaseObserver
	{
	    public InAppPurchaseObserver(Handler handler)
	    {
	      super(activity,handler);
	    }
	    
	    @Override
	    public void onBillingSupported(boolean supported)
	    {
	    	hasBillingSupport = supported;	
	      if (supported)
	      {
	        Log.d( TAG, "Billing suported");
	      }
	      else
	      {
	    	Log.d( TAG, "Billing NOT suported");
	      }
	    }
	    
	    @Override
	    public void onPurchaseStateChange(Consts.PurchaseState purchaseState, String itemId, int quantity, long purchaseTime, String developerPayload)
	    {
    		Log.d( TAG, itemId + ": " + purchaseState );

	    	if (purchaseState == Consts.PurchaseState.PURCHASED)
	    	{
	    		Log.d( TAG, "PURCHASED" );
	    	}
	    }
	    
	    @Override
	    public void onRequestPurchaseResponse(BillingService.RequestPurchase request, Consts.ResponseCode responseCode)
	    {
	    	Log.d( TAG, request.mProductId + ": " + responseCode);
	
	    	if (responseCode == Consts.ResponseCode.RESULT_OK)
	    	{
	    		Log.i( TAG, "purchase was successfully sent to server");
	    		//Send Back confirmation to Unity
	    		UnityPlayer.UnitySendMessage("RRInappBillingCallback", "productPurchased", request.mProductId);
	    		
	    	} else if (responseCode == Consts.ResponseCode.RESULT_USER_CANCELED)
	    	{
	    		Log.i( TAG, "user canceled purchase");
	    		
	    		UnityPlayer.UnitySendMessage("RRInappBillingCallback", "productPurchaseCancelled", responseCode.toString() );
	    	}
	    	else {
	    		Log.i( TAG, "purchase failed");
	    		
	    		UnityPlayer.UnitySendMessage("RRInappBillingCallback", "productPurchaseFailed", responseCode.toString() );
	    	}
	    }
	    
	    @Override
	    public void onRestoreTransactionsResponse(BillingService.RestoreTransactions request, Consts.ResponseCode responseCode)
	    {
	    	if (responseCode == Consts.ResponseCode.RESULT_OK)
	    	{
	    		SharedPreferences prefs = InAppBillingManager.this.prefs;
	    		SharedPreferences.Editor edit = prefs.edit();
	    		edit.putBoolean("db_initialized", true);
	    		edit.commit();
	    	}
	    	else
	    	{
	    		Log.d( TAG, "RestoreTransactions error: " + responseCode);
	    	}
	    }
	  }
	
}
