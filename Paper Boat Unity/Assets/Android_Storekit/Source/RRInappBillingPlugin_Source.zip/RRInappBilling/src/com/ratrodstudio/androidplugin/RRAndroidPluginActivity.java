package com.ratrodstudio.androidplugin;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.content.Intent;

import com.unity3d.player.*;

public class RRAndroidPluginActivity extends UnityPlayerActivity 
{
	private static final String TAG = "RRAndroidPluginActivity";

	protected void onCreate(Bundle savedInstanceState) {
		
		// call UnityPlayerActivity.onCreate()
		super.onCreate(savedInstanceState);
		
			//Create In App Billing Manager
		InAppBillingManager.Init( this );	  		  
		  
		// print debug message to logcat
		Log.d( TAG, "onCreate called!");
    
  }
  
  public void onBackPressed()
  {
    // instead of calling UnityPlayerActivity.onBackPressed() we just ignore the back button event
    // super.onBackPressed();
  }
  
  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
      super.onActivityResult(requestCode, resultCode, data);
      Log.d( TAG , "onActivityResult" );      
  } 
  
} 
